// Конфигурация приложения
const CONFIG = {
    openWeatherMapApiKey: '1326d50b86ffbd5db0854967695e4dd1',
    defaultMapCenter: [62.0278, 129.7315],
    defaultZoom: 11,
    aiUpdateInterval: 30000
};

// Глобальные переменные
let map;
let fields = [];
let currentUser = null;
let isDrawing = false;
let tempRectangle = null;
let startLatLng = null;
let currentCalendarMonth = new Date();
let events = [];
let fieldLayers = new L.FeatureGroup(); // Группа для всех полей

// Инициализация приложения
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Запуск AgroField...');
    initMap();
    setupEventListeners();
    checkAuthStatus();
    startAIEngine();
    
    // Первоначальные уведомления
    setTimeout(() => {
        addNotification('AgroField успешно запущен! Система настроена для Якутского региона.', 'success');
    }, 1000);
});

// ==================== КАРТА ====================
function initMap() {
    map = L.map('map').setView(CONFIG.defaultMapCenter, CONFIG.defaultZoom);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Добавляем группу полей на карту
    map.addLayer(fieldLayers);
    
    addYakutskMarkers();
    setupDrawingHandlers();
}

function addYakutskMarkers() {
    const markers = [
        { name: "Центр Якутска", coords: [62.0278, 129.7315] },
        { name: "Хатасская свиноферма", coords: [61.9850, 129.6600] },
        { name: "Аэропорт Якутск", coords: [62.0933, 129.7703] },
        { name: "Сельхозугодья", coords: [61.9500, 129.6000] }
    ];
    
    markers.forEach(marker => {
        L.marker(marker.coords).addTo(map)
            .bindPopup(`<b>${marker.name}</b><br><i>Якутск</i>`);
    });
}

// ==================== ОБРАБОТЧИКИ СОБЫТИЙ ====================
function setupEventListeners() {
    console.log('⚙️ Настройка обработчиков событий...');
    
    // Форма добавления поля
    document.getElementById('field-form').addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('🔄 Обработка формы поля...');
        saveNewField();
    });
    
 // Форма добавления события - ВАЖНО!
    document.getElementById('event-form').addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('🔄 Обработка формы события...');
        saveNewEvent();
    });
    
    // Форма входа
    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        loginUser();
    });
    
    // Форма регистрации
    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        registerUser();
    });
    
    // Закрытие модальных окон
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Клик вне модального окна
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
    
    // Переключение вкладок аутентификации
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            
            // Активируем вкладку
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Показываем соответствующую форму
            document.querySelectorAll('.auth-form').forEach(form => {
                form.classList.remove('active');
            });
            document.getElementById(`${tabName}-form`).classList.add('active');
        });
    });
    
    // Кнопка отмены рисования
    document.getElementById('cancel-draw-btn').addEventListener('click', cancelDrawingMode);
}

// ==================== АУТЕНТИФИКАЦИЯ ====================
function checkAuthStatus() {
    const savedUser = localStorage.getItem('agrofield_currentUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            updateAuthUI();
            loadUserData();
            console.log('✅ Пользователь авторизован:', currentUser.name);
        } catch (e) {
            console.error('❌ Ошибка загрузки пользователя:', e);
            localStorage.removeItem('agrofield_currentUser');
        }
    } else {
        loadDemoData();
        console.log('👤 Гостевой режим');
    }
}

function updateAuthUI() {
    const userInfo = document.getElementById('user-info');
    const userActions = document.getElementById('user-actions');
    const userName = document.getElementById('user-name');
    
    if (currentUser) {
        userInfo.style.display = 'none';
        userActions.style.display = 'flex';
        userName.textContent = currentUser.name;
    } else {
        userInfo.style.display = 'flex';
        userActions.style.display = 'none';
    }
}

function showAuthModal() {
    document.getElementById('auth-modal').style.display = 'block';
}

function loginUser() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        addNotification('Заполните все поля', 'alert');
        return;
    }
    
    const users = JSON.parse(localStorage.getItem('agrofield_users')) || [];
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        currentUser = user;
        localStorage.setItem('agrofield_currentUser', JSON.stringify(user));
        updateAuthUI();
        loadUserData();
        document.getElementById('auth-modal').style.display = 'none';
        document.getElementById('login-form').reset();
        addNotification(`Добро пожаловать, ${currentUser.name}!`, 'success');
    } else {
        addNotification('Неверный email или пароль', 'alert');
    }
}

function registerUser() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const farm = document.getElementById('register-farm').value;
    
    if (!name || !email || !password || !farm) {
        addNotification('Заполните все поля', 'alert');
        return;
    }
    
    const userData = {
        name: name,
        email: email,
        password: password,
        farm: farm,
        id: Date.now(),
        registered: new Date().toISOString()
    };
    
    let users = JSON.parse(localStorage.getItem('agrofield_users')) || [];
    
    if (users.find(u => u.email === userData.email)) {
        addNotification('Пользователь с таким email уже существует', 'alert');
        return;
    }
    
    users.push(userData);
    localStorage.setItem('agrofield_users', JSON.stringify(users));
    
    currentUser = userData;
    localStorage.setItem('agrofield_currentUser', JSON.stringify(userData));
    updateAuthUI();
    document.getElementById('auth-modal').style.display = 'none';
    document.getElementById('register-form').reset();
    
    // Создаем начальные данные для нового пользователя
    initializeNewUser();
    
    addNotification('Регистрация прошла успешно!', 'success');
}

function logout() {
    currentUser = null;
    localStorage.removeItem('agrofield_currentUser');
    updateAuthUI();
    fields = [];
    events = [];
    clearMap();
    renderFields();
    renderUpcomingEvents();
    updateStats();
    addNotification('Вы вышли из системы', 'info');
}

function initializeNewUser() {
    fields = [];
    events = [];
    saveUserData();
    renderFields();
    updateStats();
}

// ==================== УПРАВЛЕНИЕ ПОЛЯМИ ====================
function startDrawingMode() {
    if (!currentUser) {
        addNotification('Для добавления полей необходимо войти в систему', 'warning');
        showAuthModal();
        return;
    }
    
    isDrawing = true;
    const button = document.getElementById('add-field-btn');
    const cancelButton = document.getElementById('cancel-draw-btn');
    
    button.innerHTML = '<i class="fas fa-times"></i> Отменить';
    button.style.backgroundColor = '#ff9800';
    cancelButton.style.display = 'block';
    
    addNotification('Режим рисования включен! Зажмите левую кнопку мыши и протяните для создания поля.', 'info');
    
    // Временно отключаем перетаскивание карты
    map.dragging.disable();
}

function cancelDrawingMode() {
    isDrawing = false;
    const button = document.getElementById('add-field-btn');
    const cancelButton = document.getElementById('cancel-draw-btn');
    
    button.innerHTML = '<i class="fas fa-draw-polygon"></i> Добавить поле';
    button.style.backgroundColor = '';
    cancelButton.style.display = 'none';
    
    map.dragging.enable();
    
    if (tempRectangle) {
        map.removeLayer(tempRectangle);
        tempRectangle = null;
    }
    
    startLatLng = null;
}

function setupDrawingHandlers() {
    let isMouseDown = false;
    
    map.on('mousedown', function(e) {
        if (!isDrawing) return;
        isMouseDown = true;
        startLatLng = e.latlng;
        
        tempRectangle = L.rectangle([startLatLng, startLatLng], {
            color: '#ff9800',
            weight: 2,
            fillOpacity: 0.2,
            dashArray: '5, 5'
        }).addTo(map);
    });
    
    map.on('mousemove', function(e) {
        if (!isDrawing || !isMouseDown || !startLatLng || !tempRectangle) return;
        
        const bounds = L.latLngBounds(startLatLng, e.latlng);
        tempRectangle.setBounds(bounds);
    });
    
    map.on('mouseup', function(e) {
        if (!isDrawing || !isMouseDown) return;
        isMouseDown = false;
        
        if (!startLatLng || !tempRectangle) return;
        
        const bounds = tempRectangle.getBounds();
        const coordinates = [
            [bounds.getSouthWest().lat, bounds.getSouthWest().lng],
            [bounds.getSouthWest().lat, bounds.getNorthEast().lng],
            [bounds.getNorthEast().lat, bounds.getNorthEast().lng],
            [bounds.getNorthEast().lat, bounds.getSouthWest().lng],
            [bounds.getSouthWest().lat, bounds.getSouthWest().lng] // Замыкаем полигон
        ];
        
        showFieldModal([coordinates]);
        cancelDrawingMode();
    });
}

function showFieldModal(coordinates = null) {
    if (coordinates) {
        document.getElementById('field-form').dataset.coordinates = JSON.stringify(coordinates);
    }
    
    // Устанавливаем сегодняшнюю дату по умолчанию
    const today = new Date();
    document.getElementById('sowing-date').value = today.toISOString().split('T')[0];
    
    document.getElementById('field-modal').style.display = 'block';
}

function closeFieldModal() {
    document.getElementById('field-modal').style.display = 'none';
    document.getElementById('field-form').reset();
    delete document.getElementById('field-form').dataset.coordinates;
}

function saveNewField() {
    const name = document.getElementById('field-name').value;
    const crop = document.getElementById('field-crop').value;
    const sowingDate = document.getElementById('sowing-date').value;
    const area = document.getElementById('field-area').value;
    
    if (!name || !crop || !sowingDate || !area) {
        addNotification('Заполните все поля', 'alert');
        return;
    }
    
    let coordinates;
    if (document.getElementById('field-form').dataset.coordinates) {
        coordinates = JSON.parse(document.getElementById('field-form').dataset.coordinates);
    } else {
        // Если координаты не предоставлены, генерируем вокруг центра карты
        const center = map.getCenter();
        coordinates = generateFieldCoordinates(center.lat, center.lng);
    }
    
    const newField = {
        id: Date.now(),
        name: name,
        crop: crop,
        sowingDate: sowingDate,
        area: parseInt(area),
        coordinates: coordinates,
        createdAt: new Date().toISOString()
    };
    
    fields.push(newField);
    saveUserData();
    renderFields();
    addFieldToMap(newField);
    
    document.getElementById('field-modal').style.display = 'none';
    document.getElementById('field-form').reset();
    delete document.getElementById('field-form').dataset.coordinates;
    
    addNotification(`Поле "${name}" успешно добавлено!`, 'success');
    generateAIRecommendations();
}

function generateFieldCoordinates(centerLat, centerLng) {
    const size = 0.005; // Размер поля в градусах
    return [[
        [centerLat - size, centerLng - size],
        [centerLat - size, centerLng + size],
        [centerLat + size, centerLng + size],
        [centerLat + size, centerLng - size],
        [centerLat - size, centerLng - size] // Замыкаем полигон
    ]];
}

function clearMap() {
    fieldLayers.clearLayers();
}

function renderFields() {
    const fieldsList = document.getElementById('fields-list');
    fieldsList.innerHTML = '';
    
    if (fields.length === 0) {
        fieldsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-tractor"></i>
                <p>Поля не добавлены</p>
                <small>Нажмите "Добавить поле" на карте</small>
            </div>
        `;
        return;
    }
    
    fields.forEach(field => {
        const fieldElement = document.createElement('div');
        fieldElement.className = 'field-item';
        fieldElement.innerHTML = `
            <div class="field-info">
                <div class="field-name">${field.name}</div>
                <div class="field-details">
                    <span>${getCropName(field.crop)}</span>
                    <span class="field-area">${field.area} га</span>
                </div>
                <small>Посев: ${new Date(field.sowingDate).toLocaleDateString('ru-RU')}</small>
            </div>
            <div class="field-actions">
                <button class="field-action-btn" onclick="deleteField(${field.id})" title="Удалить поле">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        fieldElement.addEventListener('click', (e) => {
            if (!e.target.closest('.field-action-btn')) {
                selectField(field.id);
            }
        });
        
        fieldsList.appendChild(fieldElement);
    });
    
    // Очищаем и перерисовываем карту
    clearMap();
    fields.forEach(field => addFieldToMap(field));
}

function addFieldToMap(field) {
    const polygon = L.polygon(field.coordinates, {
        color: '#27AE60',
        fillColor: '#27AE60',
        fillOpacity: 0.3,
        weight: 2
    });
    
    polygon.addTo(fieldLayers);
    
    polygon.bindPopup(`
        <div style="min-width: 200px;">
            <h3>${field.name}</h3>
            <p><strong>Культура:</strong> ${getCropName(field.crop)}</p>
            <p><strong>Площадь:</strong> ${field.area} га</p>
            <p><strong>Дата посева:</strong> ${new Date(field.sowingDate).toLocaleDateString('ru-RU')}</p>
            <button onclick="selectField(${field.id})" 
                    style="margin-top: 10px; padding: 5px 10px; background: #27AE60; color: white; border: none; border-radius: 3px; cursor: pointer; width: 100%;">
                Выбрать это поле
            </button>
        </div>
    `);
    
    polygon.on('click', function() {
        selectField(field.id);
    });
    
    field.mapLayer = polygon;
}

function deleteField(fieldId) {
    if (!confirm('Вы уверены, что хотите удалить это поле?')) return;
    
    const fieldIndex = fields.findIndex(f => f.id === fieldId);
    if (fieldIndex === -1) return;
    
    const fieldName = fields[fieldIndex].name;
    
    // Удаляем слой с карты
    if (fields[fieldIndex].mapLayer) {
        fieldLayers.removeLayer(fields[fieldIndex].mapLayer);
    }
    
    // Удаляем связанные события
    events = events.filter(event => event.fieldId !== fieldId);
    
    fields.splice(fieldIndex, 1);
    saveUserData();
    renderFields();
    renderUpcomingEvents();
    updateStats();
    
    addNotification(`Поле "${fieldName}" удалено`, 'warning');
}

function selectField(fieldId) {
    const field = fields.find(f => f.id === fieldId);
    if (!field || !field.mapLayer) return;
    
    map.fitBounds(field.mapLayer.getBounds());
    field.mapLayer.openPopup();
    updateWeatherForField(field);
    
    // Подсвечиваем выбранное поле
    document.querySelectorAll('.field-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`.field-item`).classList.add('active'); // Простая подсветка
}

// ==================== КАЛЕНДАРЬ РАБОТ ====================
function showCalendarModal() {
    if (!currentUser) {
        addNotification('Для доступа к календарю необходимо войти в систему', 'warning');
        showAuthModal();
        return;
    }
    
    renderCalendar();
    document.getElementById('calendar-modal').style.display = 'block';
}

function renderCalendar() {
    const calendarGrid = document.getElementById('calendar-grid');
    const monthYear = document.getElementById('current-month');
    
    // Устанавливаем название месяца и года
    monthYear.textContent = currentCalendarMonth.toLocaleDateString('ru-RU', {
        month: 'long',
        year: 'numeric'
    });
    
    // Очищаем календарь
    calendarGrid.innerHTML = '';
    
    // Получаем первый и последний день месяца
    const firstDay = new Date(currentCalendarMonth.getFullYear(), currentCalendarMonth.getMonth(), 1);
    const lastDay = new Date(currentCalendarMonth.getFullYear(), currentCalendarMonth.getMonth() + 1, 0);
    const daysInMonth = lastDay.getDate();
    
    // Добавляем заголовки дней недели
    const daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    daysOfWeek.forEach(day => {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day-header';
        dayElement.textContent = day;
        calendarGrid.appendChild(dayElement);
    });
    
    // Добавляем пустые ячейки для первых дней месяца
    const startDayOfWeek = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1;
    for (let i = 0; i < startDayOfWeek; i++) {
        calendarGrid.appendChild(document.createElement('div'));
    }
    
    // Добавляем дни месяца
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        dayElement.textContent = day;
        
        // Форматируем дату для сравнения
        const dateStr = `${currentCalendarMonth.getFullYear()}-${(currentCalendarMonth.getMonth() + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        
        // Проверяем есть ли события на этот день
        const dayEvents = events.filter(event => event.date === dateStr);
        
        if (dayEvents.length > 0) {
            dayElement.classList.add('has-events');
            dayElement.title = dayEvents.map(e => e.title).join('\n');
        }
        
        // Проверяем является ли день текущим
        const today = new Date();
        if (day === today.getDate() && 
            currentCalendarMonth.getMonth() === today.getMonth() && 
            currentCalendarMonth.getFullYear() === today.getFullYear()) {
            dayElement.classList.add('current');
        }
        
        dayElement.addEventListener('click', () => {
            if (dayEvents.length > 0) {
                showDayEvents(dateStr, dayEvents);
            }
        });
        
        calendarGrid.appendChild(dayElement);
    }
}

function changeCalendarMonth(direction) {
    currentCalendarMonth.setMonth(currentCalendarMonth.getMonth() + direction);
    renderCalendar();
}

function showAddEventModal() {
    console.log('📅 Открытие модального окна добавления события...');
    
    const fieldSelect = document.getElementById('event-field');
    fieldSelect.innerHTML = '<option value="">Выберите поле</option>';
    
    if (fields.length === 0) {
        addNotification('Сначала добавьте поле', 'warning');
        return;
    }
    
    fields.forEach(field => {
        const option = document.createElement('option');
        option.value = field.id;
        option.textContent = field.name;
        fieldSelect.appendChild(option);
    });
    
    // Устанавливаем сегодняшнюю дату по умолчанию
    const today = new Date();
    document.getElementById('event-date').value = today.toISOString().split('T')[0];
    
    // Очищаем остальные поля
    document.getElementById('event-title').value = '';
    document.getElementById('event-type').value = 'sowing';
    document.getElementById('event-description').value = '';
    
    document.getElementById('event-modal').style.display = 'block';
    console.log('✅ Модальное окно события открыто');
}

function closeEventModal() {
    document.getElementById('event-modal').style.display = 'none';
    document.getElementById('event-form').reset();
}

function saveNewEvent() {
    console.log('📝 Попытка сохранения события...');
    
    const title = document.getElementById('event-title').value;
    const fieldId = parseInt(document.getElementById('event-field').value);
    const type = document.getElementById('event-type').value;
    const date = document.getElementById('event-date').value;
    const description = document.getElementById('event-description').value;

    console.log('Данные формы:', { title, fieldId, type, date, description });

    // Проверка обязательных полей
    if (!title || !fieldId || !date) {
        addNotification('Заполните обязательные поля: название, поле и дата', 'alert');
        console.log('❌ Ошибка: не заполнены обязательные поля');
        return false;
    }

    // Проверка существования поля
    const field = fields.find(f => f.id === fieldId);
    if (!field) {
        addNotification('Выберите существующее поле', 'alert');
        console.log('❌ Ошибка: поле не найдено');
        return false;
    }

    // Создание нового события
    const newEvent = {
        id: Date.now(),
        title: title,
        fieldId: fieldId,
        fieldName: field.name,
        type: type,
        date: date,
        description: description,
        createdAt: new Date().toISOString()
    };

    console.log('✅ Новое событие:', newEvent);

    // Добавление события
    events.push(newEvent);
    saveUserData();
    
    // Обновление интерфейса
    renderUpcomingEvents();
    renderCalendar();
    closeEventModal();
    
    addNotification(`Событие "${title}" успешно добавлено в календарь!`, 'success');
    console.log('✅ Событие сохранено');

    return false; // Предотвращаем перезагрузку страницы
}

function showDayEvents(dateStr, dayEvents) {
    const eventList = dayEvents.map(event => 
        `• ${event.title} (${event.fieldName}) - ${event.description || 'Без описания'}`
    ).join('\n\n');
    
    alert(`📅 События на ${new Date(dateStr).toLocaleDateString('ru-RU')}:\n\n${eventList}`);
}

function renderUpcomingEvents() {
    const upcomingEvents = document.getElementById('upcoming-events');
    const today = new Date().toISOString().split('T')[0];
    
    const futureEvents = events
        .filter(event => event.date >= today)
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 5);
    
    if (futureEvents.length === 0) {
        upcomingEvents.innerHTML = '<p style="color: #666; font-style: italic; text-align: center;">Нет предстоящих событий</p>';
        return;
    }
    
    upcomingEvents.innerHTML = futureEvents.map(event => `
        <div class="event-item" style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; border-left: 3px solid #27AE60;">
            <div style="font-weight: 600; color: #2D3748;">${new Date(event.date).toLocaleDateString('ru-RU')}</div>
            <div style="margin: 5px 0;">${event.title}</div>
            <div style="font-size: 0.8rem; color: #666;">
                <i class="fas fa-map-marker-alt"></i> ${event.fieldName}
                ${event.description ? `• ${event.description}` : ''}
            </div>
        </div>
    `).join('');
}

// ==================== AI РЕКОМЕНДАЦИИ ====================
function startAIEngine() {
    generateAIRecommendations();
    // Обновляем рекомендации каждые 30 секунд
    setInterval(generateAIRecommendations, CONFIG.aiUpdateInterval);
}

function showAIRecommendations() {
    generateAIRecommendations();
    addNotification('AI рекомендации обновлены', 'info');
}

function generateAIRecommendations() {
    const aiContainer = document.getElementById('ai-recommendations');
    
    if (fields.length === 0) {
        aiContainer.innerHTML = `
            <div class="ai-loading">
                <i class="fas fa-robot"></i>
                <p>Добавьте поля для получения рекомендаций</p>
                <small>Нажмите "Добавить поле" на карте</small>
            </div>
        `;
        return;
    }
    
    const recommendations = [];
    const today = new Date();
    const month = today.getMonth() + 1; // 1-12
    
    // Анализ каждого поля
    fields.forEach(field => {
        const sowingDate = new Date(field.sowingDate);
        const daysSinceSowing = Math.floor((today - sowingDate) / (1000 * 60 * 60 * 24));
        
        // Рекомендации на основе времени после посева
        if (daysSinceSowing < 0) {
            recommendations.push({
                type: 'info',
                message: `⏳ До посева на поле "${field.name}" осталось ${-daysSinceSowing} дней. Подготовьте технику.`
            });
        } else if (daysSinceSowing >= 0 && daysSinceSowing < 7) {
            recommendations.push({
                type: 'info',
                message: `🌱 Поле "${field.name}": ожидайте всходов через ${7 - daysSinceSowing} дней. Поддерживайте влажность.`
            });
        } else if (daysSinceSowing >= 7 && daysSinceSowing < 21) {
            recommendations.push({
                type: 'warning',
                message: `🌿 Поле "${field.name}": через ${21 - daysSinceSowing} дней потребуется внесение удобрений.`
            });
        } else if (daysSinceSowing >= 21 && daysSinceSowing < 90) {
            const daysToHarvest = 90 - daysSinceSowing;
            recommendations.push({
                type: 'info',
                message: `🌾 Поле "${field.name}": до уборки урожая ${daysToHarvest} дней. Контролируйте рост.`
            });
        }
    });
    
    // Сезонные рекомендации для Якутска
    if (month >= 5 && month <= 6) {
        recommendations.push({
            type: 'info',
            message: '🌞 Лето: оптимальное время для роста культур. Увеличьте полив в жаркие дни.'
        });
    } else if (month >= 9 && month <= 10) {
        recommendations.push({
            type: 'warning',
            message: '🍂 Осень: подготовка к зиме. Завершите уборочные работы до заморозков.'
        });
    }
    
    // Специфические рекомендации для Якутска
    recommendations.push({
        type: 'warning',
        message: '❄️ Якутск: будьте готовы к резким перепадам температур. Утепляйте чувствительные культуры.'
    });
    
    if (recommendations.length === 0) {
        aiContainer.innerHTML = `
            <div class="ai-recommendation success">
                <p>✅ Все процессы идут по плану! Продолжайте текущие работы.</p>
            </div>
        `;
    } else {
        // Ограничиваем количество рекомендаций и выводим самые важные
        const importantRecommendations = recommendations
            .sort((a, b) => (b.type === 'warning' ? 1 : 0) - (a.type === 'warning' ? 1 : 0))
            .slice(0, 4);
        
        aiContainer.innerHTML = importantRecommendations.map(rec => `
            <div class="ai-recommendation ${rec.type}">
                <p>${rec.message}</p>
                <small>AI • ${new Date().toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'})}</small>
            </div>
        `).join('');
    }
}

// ==================== ОТЧЕТЫ ====================
function generateReport() {
    if (!currentUser) {
        addNotification('Для просмотра отчетов необходимо войти в систему', 'warning');
        showAuthModal();
        return;
    }
    
    if (fields.length === 0) {
        addNotification('Нет данных для отчета. Добавьте поля.', 'info');
        return;
    }
    
    const reportContent = document.getElementById('report-content');
    const totalArea = fields.reduce((sum, field) => sum + field.area, 0);
    const today = new Date().toISOString().split('T')[0];
    const upcomingEvents = events.filter(e => e.date >= today).length;
    
    // Статистика по культурам
    const cropStats = {};
    fields.forEach(field => {
        if (!cropStats[field.crop]) {
            cropStats[field.crop] = { count: 0, area: 0, fields: [] };
        }
        cropStats[field.crop].count++;
        cropStats[field.crop].area += field.area;
        cropStats[field.crop].fields.push(field.name);
    });
    
    reportContent.innerHTML = `
        <div class="report-section">
            <h3 style="color: #2D3748; margin-bottom: 15px;">📊 Общая статистика хозяйства</h3>
            <div class="report-stats">
                <div class="report-stat">
                    <div class="report-stat-value">${fields.length}</div>
                    <div class="report-stat-label">полей</div>
                </div>
                <div class="report-stat">
                    <div class="report-stat-value">${totalArea}</div>
                    <div class="report-stat-label">гектаров</div>
                </div>
                <div class="report-stat">
                    <div class="report-stat-value">${upcomingEvents}</div>
                    <div class="report-stat-label">задач</div>
                </div>
            </div>
        </div>
        
        <div class="report-section">
            <h4 style="color: #2D3748; margin: 20px 0 10px 0;">🌾 Распределение по культурам</h4>
            <div class="report-list">
                ${Object.entries(cropStats).map(([crop, stats]) => `
                    <div class="report-item">
                        <strong>${getCropName(crop)}</strong>
                        <div>${stats.count} полей, ${stats.area} га</div>
                        <small>${stats.fields.join(', ')}</small>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="report-section">
            <h4 style="color: #2D3748; margin: 20px 0 10px 0;">📅 Ближайшие события (5 дней)</h4>
            <div class="report-list">
                ${getUpcomingEventsReport()}
            </div>
        </div>
        
        <div class="report-section">
            <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-top: 20px;">
                <h4 style="color: #2D3748; margin: 0 0 10px 0;">💡 Рекомендации AI</h4>
                <div style="font-size: 0.9rem;">
                    ${getAIReportRecommendations()}
                </div>
            </div>
        </div>
        
        <div style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;">
            <small style="color: #666;">
                Отчет сгенерирован: ${new Date().toLocaleDateString('ru-RU')} в ${new Date().toLocaleTimeString('ru-RU')}<br>
                Хозяйство: ${currentUser.farm}<br>
                Пользователь: ${currentUser.name}
            </small>
        </div>
    `;
    
    document.getElementById('report-modal').style.display = 'block';
}

function getUpcomingEventsReport() {
    const today = new Date();
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 5);
    
    const upcoming = events
        .filter(e => {
            const eventDate = new Date(e.date);
            return eventDate >= today && eventDate <= nextWeek;
        })
        .sort((a, b) => new Date(a.date) - new Date(b.date));
    
    if (upcoming.length === 0) {
        return '<p style="color: #666; font-style: italic; text-align: center;">Нет событий на ближайшие 5 дней</p>';
    }
    
    return upcoming.map(event => `
        <div class="report-item">
            <strong>${new Date(event.date).toLocaleDateString('ru-RU')}</strong>
            <div>${event.title} • ${event.fieldName}</div>
            ${event.description ? `<small>${event.description}</small>` : ''}
        </div>
    `).join('');
}

function getAIReportRecommendations() {
    if (fields.length === 0) return '<p>Добавьте поля для получения рекомендаций</p>';
    
    const today = new Date();
    const recommendations = [];
    
    fields.forEach(field => {
        const sowingDate = new Date(field.sowingDate);
        const daysSinceSowing = Math.floor((today - sowingDate) / (1000 * 60 * 60 * 24));
        
        if (daysSinceSowing >= 7 && daysSinceSowing < 21) {
            recommendations.push(`Поле "${field.name}" требует подкормки через ${21 - daysSinceSowing} дней`);
        }
    });
    
    return recommendations.length > 0 
        ? recommendations.map(rec => `• ${rec}`).join('<br>')
        : 'Все процессы идут по плану. Продолжайте текущие работы.';
}

// ==================== ПОГОДА ====================
async function updateWeatherForField(field) {
    const weatherInfo = document.getElementById('weather-info');
    
    try {
        // Получаем центр поля
        const polygon = L.polygon(field.coordinates[0]);
        const center = polygon.getBounds().getCenter();
        
        // Используем демо-данные, так как API ключ может не работать
        const demoWeather = getDemoWeatherData();
        
        weatherInfo.innerHTML = `
            <div class="weather-current">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                    <div class="weather-temp">${demoWeather.temperature}°C</div>
                    <div class="weather-icon" style="font-size: 2rem;">${demoWeather.icon}</div>
                </div>
                <div class="weather-desc">${demoWeather.description}</div>
                <div class="weather-details" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
                    <div><i class="fas fa-tint"></i> ${demoWeather.humidity}%</div>
                    <div><i class="fas fa-wind"></i> ${demoWeather.windSpeed} м/с</div>
                    <div><i class="fas fa-temperature-low"></i> ${demoWeather.feelsLike}°C</div>
                    <div><i class="fas fa-compress-arrows-alt"></i> ${demoWeather.pressure} hPa</div>
                </div>
                <div style="margin-top: 10px; font-size: 0.8rem; color: #666;">
                    <i class="fas fa-map-marker-alt"></i> ${field.name}
                </div>
            </div>
        `;
        
    } catch (error) {
        console.error('Ошибка загрузки погоды:', error);
        weatherInfo.innerHTML = `
            <div style="text-align: center; color: #666; padding: 20px;">
                <i class="fas fa-cloud-sun" style="font-size: 2rem; margin-bottom: 10px;"></i>
                <p>Данные о погоде временно недоступны</p>
            </div>
        `;
    }
}

function getDemoWeatherData() {
    const weatherTypes = [
        { icon: '☀️', description: 'Солнечно', temp: 15, humidity: 45, wind: 2 },
        { icon: '⛅', description: 'Переменная облачность', temp: 12, humidity: 60, wind: 3 },
        { icon: '☁️', description: 'Облачно', temp: 10, humidity: 70, wind: 4 },
        { icon: '🌧️', description: 'Небольшой дождь', temp: 8, humidity: 85, wind: 3 }
    ];
    
    const randomWeather = weatherTypes[Math.floor(Math.random() * weatherTypes.length)];
    
    return {
        temperature: randomWeather.temp + Math.floor(Math.random() * 5),
        description: randomWeather.description,
        humidity: randomWeather.humidity + Math.floor(Math.random() * 10),
        windSpeed: randomWeather.wind + Math.floor(Math.random() * 3),
        feelsLike: (randomWeather.temp - 2) + Math.floor(Math.random() * 3),
        pressure: 750 + Math.floor(Math.random() * 20),
        icon: randomWeather.icon
    };
}

// ==================== УВЕДОМЛЕНИЯ ====================
function addNotification(message, type = 'info') {
    const notificationsList = document.getElementById('notifications-list');
    const notificationId = 'notif-' + Date.now();
    
    const notification = document.createElement('div');
    notification.id = notificationId;
    notification.className = `notification-item ${type}`;
    notification.innerHTML = `
        <div class="notification-content">${message}</div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px;">
            <small>${new Date().toLocaleTimeString('ru-RU')}</small>
            <button class="notification-close" onclick="document.getElementById('${notificationId}').remove()" 
                    style="background: none; border: none; color: #666; cursor: pointer; padding: 2px 5px;">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    notificationsList.appendChild(notification);
    
    // Автоудаление через 15 секунд
    setTimeout(() => {
        const element = document.getElementById(notificationId);
        if (element) {
            element.style.opacity = '0';
            element.style.transition = 'opacity 0.3s';
            setTimeout(() => {
                if (element.parentNode) element.remove();
            }, 300);
        }
    }, 15000);
}

function clearAllNotifications() {
    document.getElementById('notifications-list').innerHTML = '';
}

// ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================
function getCropName(cropCode) {
    const crops = {
        'wheat': 'Пшеница',
        'barley': 'Ячмень',
        'corn': 'Кукуруза',
        'sunflower': 'Подсолнечник',
        'potato': 'Картофель',
        'vegetables': 'Овощи'
    };
    return crops[cropCode] || cropCode;
}

function loadUserData() {
    if (!currentUser) return;
    
    const userData = JSON.parse(localStorage.getItem(`agrofield_data_${currentUser.id}`)) || {};
    fields = userData.fields || [];
    events = userData.events || [];
    
    renderFields();
    renderUpcomingEvents();
    updateStats();
    generateAIRecommendations();
    
    console.log('📂 Данные пользователя загружены:', { 
        fields: fields.length, 
        events: events.length 
    });
}

function saveUserData() {
    if (!currentUser) return;
    
    const userData = {
        fields: fields,
        events: events,
        lastUpdated: new Date().toISOString()
    };
    localStorage.setItem(`agrofield_data_${currentUser.id}`, JSON.stringify(userData));
}

function loadDemoData() {
    // Демо-данные для гостей
    fields = [
        {
            id: 1,
            name: "Северное поле",
            crop: "wheat",
            area: 50,
            sowingDate: "2024-05-15",
            coordinates: [[
                [62.035, 129.73],
                [62.035, 129.74],
                [62.025, 129.74],
                [62.025, 129.73],
                [62.035, 129.73]
            ]]
        },
        {
            id: 2,
            name: "Южное поле",
            crop: "barley",
            area: 35,
            sowingDate: "2024-05-20",
            coordinates: [[
                [62.020, 129.72],
                [62.020, 129.73],
                [62.015, 129.73],
                [62.015, 129.72],
                [62.020, 129.72]
            ]]
        }
    ];
    
    events = [
        {
            id: 1,
            title: "Посев пшеницы",
            fieldId: 1,
            fieldName: "Северное поле",
            type: "sowing",
            date: "2024-05-15",
            description: "Посев яровой пшеницы"
        },
        {
            id: 2,
            title: "Внесение удобрений",
            fieldId: 1,
            fieldName: "Северное поле",
            type: "fertilizing",
            date: "2024-06-01",
            description: "Азотные удобрения"
        }
    ];
    
    renderFields();
    renderUpcomingEvents();
    updateStats();
    generateAIRecommendations();
}

function updateStats() {
    document.getElementById('total-fields').textContent = fields.length;
    document.getElementById('total-area').textContent = fields.reduce((sum, field) => sum + field.area, 0);
    
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('active-tasks').textContent = events.filter(e => e.date >= today).length;
}

// ==================== ГЛОБАЛЬНЫЕ ФУНКЦИИ ДЛЯ HTML ====================
window.showAuthModal = showAuthModal;
window.logout = logout;
window.showCalendarModal = showCalendarModal;
window.changeCalendarMonth = changeCalendarMonth;
window.showAddEventModal = showAddEventModal;
window.closeEventModal = closeEventModal;
window.clearAllNotifications = clearAllNotifications;
window.startDrawingMode = startDrawingMode;
window.deleteField = deleteField;
window.generateReport = generateReport;
window.showAIRecommendations = showAIRecommendations;

console.log('✅ AgroField инициализирован!');
function testEventAdding() {
    console.log('🧪 Тестирование добавления события...');
    
    // Проверяем, есть ли поля
    if (fields.length === 0) {
        console.log('❌ Нет полей для тестирования');
        return;
    }
    
    // Создаем тестовое событие
    const testEvent = {
        id: Date.now(),
        title: 'Тестовое событие',
        fieldId: fields[0].id,
        fieldName: fields[0].name,
        type: 'sowing',
        date: new Date().toISOString().split('T')[0],
        description: 'Это тестовое событие',
        createdAt: new Date().toISOString()
    };
    
    events.push(testEvent);
    saveUserData();
    renderUpcomingEvents();
    
    console.log('✅ Тестовое событие добавлено');
    addNotification('Тестовое событие добавлено!', 'success');
}

// Добавьте эту кнопку временно в HTML для тестирования:
// <button onclick="testEventAdding()">Тест добавления события</button>

// Добавьте в конец script.js
document.addEventListener('DOMContentLoaded', function() {
    // Аварийный обработчик для кнопки сохранения события
    document.addEventListener('click', function(e) {
        if (e.target.closest('#event-form .btn-primary')) {
            e.preventDefault();
            console.log('🆘 Аварийный обработчик сработал!');
            saveNewEvent();
        }
    });
});